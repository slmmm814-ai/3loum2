# -*- coding: utf-8 -*-
"""
Phase 2c: بحث دلالي حقيقي على مستوى الفقرة عبر TF-IDF + LSA (SVD).
لا يعتمد على أي نموذج مُنزَّل من الإنترنت؛ خفيف على الذاكرة (~3.9GB متاحة).
"""
import sqlite3, re, sys, pickle, time
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD

DB = "فهرس_البلاغة_full_sqlite3_enhanced_v2_db"
AR_TOKEN_RE = re.compile(r"[\u0621-\u064A]+")
DIACRITICS_RE = re.compile(r"[\u064B-\u0652\u0670\u0640]")

def normalize_ar(text):
    text = DIACRITICS_RE.sub("", text)
    text = text.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    text = text.replace("ى", "ي").replace("ة", "ه")
    return text

def tokenize(text):
    return [normalize_ar(t) for t in AR_TOKEN_RE.findall(text) if len(t) > 1]

def main():
    t0 = time.time()
    db = sqlite3.connect(DB)
    cur = db.cursor()
    cur.execute("SELECT passage_id, text FROM passages ORDER BY passage_id")
    rows = cur.fetchall()
    ids = [r[0] for r in rows]
    print(f"عدد الفقرات: {len(ids)}", file=sys.stderr)

    joined = [" ".join(tokenize(t)) for _, t in rows]

    vectorizer = TfidfVectorizer(min_df=2, max_df=0.9, sublinear_tf=True, dtype=np.float32)
    tfidf = vectorizer.fit_transform(joined)
    print(f"TF-IDF: {tfidf.shape} ({time.time()-t0:.0f}s)", file=sys.stderr)

    n_components = 300
    svd = TruncatedSVD(n_components=n_components, random_state=42)
    lsa_vectors = svd.fit_transform(tfidf)
    print(f"LSA جاهز ({time.time()-t0:.0f}s), تباين مُفسَّر: {svd.explained_variance_ratio_.sum():.3f}", file=sys.stderr)

    norms = np.linalg.norm(lsa_vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1
    lsa_vectors = (lsa_vectors / norms).astype(np.float32)

    np.save("passage_vectors_lsa.npy", lsa_vectors)
    with open("passage_ids.pkl", "wb") as f:
        pickle.dump(ids, f)
    with open("tfidf_vectorizer.pkl", "wb") as f:
        pickle.dump(vectorizer, f)
    with open("svd_model.pkl", "wb") as f:
        pickle.dump(svd, f)

    print(f"تم الحفظ. الوقت الكلي: {time.time()-t0:.0f}s", file=sys.stderr)

if __name__ == "__main__":
    main()
