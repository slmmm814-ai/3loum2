# -*- coding: utf-8 -*-
"""
Phase 2b (نسخة مُحسّنة للذاكرة المحدودة ~4GB):
يعيد استخدام fasttext_balagha.model المُدرَّب فعلاً، ويبني fasttext_similarity
لأعلى N كلمة تكرارًا فقط (كافٍ عمليًا وأخف على الذاكرة/الوقت)، مع تسجيل تقدّم
دوري و commit متكرر لتفادي فقدان العمل عند أي انقطاع.
"""
import sqlite3, sys, time
from gensim.models import FastText

DB = "فهرس_البلاغة_full_sqlite3_enhanced_v2_db"
TOP_N_WORDS = 20000   # كافٍ لتغطية كل المفردات المتكررة عمليًا في المتن
TOPN_SIM = 8

def main():
    t0 = time.time()
    print("تحميل النموذج المُدرّب مسبقًا ...", file=sys.stderr)
    ft = FastText.load("fasttext_balagha.model")
    print(f"تم التحميل ({time.time()-t0:.1f}s). حجم القاموس: {len(ft.wv.key_to_index)}", file=sys.stderr)

    # ترتيب الكلمات بحسب التكرار (gensim يحفظها مرتبة تنازليًا أصلاً غالبًا،
    # لكن نتحقق باستخدام count الفعلي لضمان الصحة)
    words_by_freq = sorted(
        ft.wv.key_to_index.keys(),
        key=lambda w: ft.wv.get_vecattr(w, "count"),
        reverse=True,
    )[:TOP_N_WORDS]

    db = sqlite3.connect(DB)
    cur = db.cursor()
    cur.execute("DELETE FROM fasttext_similarity")
    db.commit()

    rid = 1
    buf = []
    for i, w in enumerate(words_by_freq, start=1):
        try:
            sims = ft.wv.most_similar(w, topn=TOPN_SIM)
        except Exception:
            continue
        for related, score in sims:
            buf.append((rid, w, related, float(score)))
            rid += 1
        if len(buf) >= 5000:
            cur.executemany("INSERT INTO fasttext_similarity VALUES (?,?,?,?)", buf)
            db.commit()
            buf = []
        if i % 2000 == 0:
            print(f"{i}/{len(words_by_freq)} كلمة ({time.time()-t0:.0f}s)", file=sys.stderr)
    if buf:
        cur.executemany("INSERT INTO fasttext_similarity VALUES (?,?,?,?)", buf)
        db.commit()

    cur.execute("SELECT COUNT(*) FROM fasttext_similarity")
    print(f"إجمالي سجلات التشابه: {cur.fetchone()[0]}  (الوقت الكلي: {time.time()-t0:.0f}s)", file=sys.stderr)


if __name__ == "__main__":
    main()
