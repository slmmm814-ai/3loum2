# تحديثات فهرس البلاغة (v3) — أدوات بحث متقدمة

## ما الذي أُضيف

| الميزة المطلوبة | الحل المنفَّذ | الملف/الجدول |
|---|---|---|
| بحث دلالي أقوى من Word2Vec | **FastText** مُدرَّب محليًا على المتن (100 بُعد، subword n-grams 2-5، يعالج التصريف العربي والكلمات غير المرصودة) | `fasttext_balagha.model*`, جدول `fasttext_similarity` |
| بحث دلالي حقيقي (semantic) | **TF-IDF + LSA/SVD** بمتجه 300 بُعد لكل فقرة، تشابه بجيب التمام | `passage_vectors_lsa.npy`, `tfidf_vectorizer.pkl`, `svd_model.pkl` |
| حفظ موضع الفقرة/الجملة، لا الصفحة فقط | تفكيك 21,643 صفحة إلى **73,199 فقرة/جملة** مع نوع كل وحدة (عنوان/فقرة/جملة) | جدول `passages` + `passages_fts` |
| بحث هجين BM25 + fuzzy + semantic + reranking | دالة `hybrid_search()` تدمج الثلاثة بأوزان، مع تعزيز عند تطابق العبارة الحرفية | `04_hybrid_search.py` |
| نظام موحّد للاستشهادات/المراجع | دمج `book_citations` + `isnad_candidates` + `duplicate_candidates` في جدول واحد مربوط بالفقرات | جدول `citations_unified` |
| إضافة صفحات جديدة دون إعادة بناء كل الفهارس | سكريبت يُلحق فقط: صفحات + فقرات + تحديث FastText تدريجي (`build_vocab(update=True)`) + تحويل LSA (بدون إعادة تدريب SVD) | `05_add_book_incremental.py` |
| واجهة API للبحث | Flask API: `/search`, `/book/<id>`, `/passage/<id>`, `/citations/<book_id>` | `06_search_api.py` |

## التشغيل

```bash
pip install flask gensim scikit-learn numpy --break-system-packages

# بحث من سطر الأوامر
python3 04_hybrid_search.py "الاستعارة والتشبيه"

# تشغيل واجهة API
python3 06_search_api.py
# ثم: curl "http://localhost:8008/search?q=الاستعارة&top_k=10"

# إضافة كتاب جديد بدون إعادة بناء الفهارس
python3 05_add_book_incremental.py --json new_book.json
```

صيغة `new_book.json` المطلوبة لإضافة كتاب موضّحة في تعليق رأس `05_add_book_incremental.py`.

## قيود مهمة يجب معرفتها

1. **لا يوجد وصول لـ Hugging Face** في بيئة التنفيذ هذه، لذا لم يكن ممكنًا استخدام نموذج
   embeddings عصبي جاهز (مثل AraBERT/LaBSE) أو reranker عصبي. الحل المستخدم (FastText محلي +
   TF-IDF/LSA + reranking بوزن مُرجَّح) حقيقي وفعّال، لكنه ليس بجودة نموذج transformer
   مُدرَّب على مليارات الكلمات. إن رغبت بذلك لاحقًا فعّل الوصول لـ huggingface.co من إعدادات
   الشبكة وسأدمج نموذج embeddings عربي فعلي.
2. **تفكيك الفقرات اعتماديّ على فواصل الأسطر** في النص الأصلي (لا توجد علامات فقرة صريحة
   في البيانات المصدر)، فبعض الفقرات قد تكون أطول/أقصر من الحدّ المثالي في حالات نادرة.
3. **FTS5 trigram وكلمات قصيرة**: كلمات من حرفين فقط (مثل "من"، "في") لا يمكن تمثيلها
   بمقتطعات ثلاثية (trigram)، فقد يفشل شرط MATCH إذا ظهرت هذه الكلمات ضمن استعلام متعدد
   الكلمات بصيغة AND الافتراضية. الحل العملي: صياغة الاستعلامات بالكلمات المفتاحية الدالة
   (وهذا ما تفعله `hybrid_search` تلقائيًا عبر التوسّع الدلالي والـ fuzzy).
4. **تفسير التباين لـ LSA ~17.8%** عند 300 بُعد — طبيعي لنص عربي متخصص بمفردات كثيرة؛
   الترتيب النسبي للنتائج هو ما يهم في البحث، لا نسبة إعادة البناء الكاملة.
5. **البيئة محدودة الذاكرة (~3.9GB)** — تجنّبت حساب تشابه FastText لكل القاموس (109,247 كلمة)
   واستخدمت أعلى 20,000 كلمة تكرارًا فقط (كافية عمليًا)؛ يمكن رفع هذا الحد لو توفرت ذاكرة أكبر.

## الجداول الجديدة في قاعدة البيانات

- `passages` — الوحدة الأساسية الجديدة للبحث (فقرة/جملة/عنوان) بربط كامل بالكتاب والصفحة.
- `passages_fts` — فهرس FTS5 (trigram) على مستوى الفقرة.
- `fasttext_similarity` — أقرب 8 كلمات لكل كلمة من أعلى 20,000 كلمة تكرارًا.
- `citations_unified` — نظام موحّد: `citation_type` ∈ {book_citation, isnad, duplicate}.

## ملفات مرافقة لقاعدة البيانات (يجب حفظها معًا في نفس المجلد)

`fasttext_balagha.model` + ملفات `.npy` المرتبطة به، `passage_vectors_lsa.npy`,
`passage_ids.pkl`, `tfidf_vectorizer.pkl`, `svd_model.pkl` — هذه ليست داخل SQLite لأن
تخزين مصفوفات عائمة كبيرة كـ BLOB في SQLite أبطأ بكثير من numpy.memmap/load المباشر.
