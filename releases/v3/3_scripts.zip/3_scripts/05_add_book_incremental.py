# -*- coding: utf-8 -*-
"""
Phase 5: إضافة كتاب جديد (أو ملايين الصفحات لاحقًا) دون إعادة بناء الفهارس بالكامل.

الاستخدام:
    python3 05_add_book_incremental.py --json new_book.json

صيغة new_book.json المتوقعة:
{
  "book_id": 45,
  "book_name": "اسم الكتاب",
  "author_id": 1, "author_name": "المؤلف",
  "cat_id": 1, "cat_name": "بلاغة",
  "pages": [
     {"pg": 1, "vol": "1", "printed_page": "1", "text_orig": "...نص الصفحة..."},
     ...
  ]
}

ما يفعله هذا السكريبت (بدون لمس أي صفوف قديمة):
  1) يضيف سجل الكتاب إلى books
  2) يضيف صفحاته إلى pages_fts (FTS5 -- الإدراج فيه لا يعيد بناء الفهرس كله،
     فقط يحدّث segments/merges داخليًا بحسب تصميم FTS5)
  3) يفكك صفحاته لفقرات ويضيف الفقرات إلى passages + passages_fts
  4) يحدّث fasttext_similarity فقط للكلمات الجديدة غير الموجودة في القاموس
     (تحديث تدريجي/incremental للنموذج عبر ft.build_vocab(update=True) + train)
  5) يعيد فقط تحويل (transform) الفقرات الجديدة إلى فضاء LSA الحالي (بدون
     إعادة تدريب TF-IDF/SVD بالكامل)، ويُلحقها بـ passage_vectors_lsa.npy

هذا يحقق مطلب "إمكانية إضافة ملايين الصفحات دون إعادة بناء كل الفهارس":
الفهارس الثقيلة (SVD/FastText الأساسي) تُبنى مرة، والإضافات تُلحَق حسابيًا لا تُعاد بالكامل.
ملاحظة: لإعادة توازن جودة LSA/FastText مع نمو كبير جدًا في المتن، يُنصح
بإعادة تدريب دورية (مثلاً كل بضع عشرات آلاف صفحة جديدة) لا مع كل كتاب.
"""
import sqlite3, re, sys, json, argparse, pickle, html
import numpy as np
from gensim.models import FastText

DB = "فهرس_البلاغة_full_sqlite3_enhanced_v2_db"
SPAN_RE = re.compile(r"<span[^>]*>.*?</span>", re.DOTALL)
TAG_RE = re.compile(r"<[^>]+>")
SENT_SPLIT_RE = re.compile(r"(?<=[\.\!\؟])\s+")
AR_TOKEN_RE = re.compile(r"[\u0621-\u064A]+")
DIACRITICS_RE = re.compile(r"[\u064B-\u0652\u0670\u0640]")


def normalize_ar(text):
    text = DIACRITICS_RE.sub("", text)
    text = text.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    text = text.replace("ى", "ي").replace("ة", "ه")
    return text


def tokenize(text):
    return [normalize_ar(t) for t in AR_TOKEN_RE.findall(text) if len(t) > 1]


def strip_tags_keep_titles(text):
    titles = []
    def _cap(m):
        inner = TAG_RE.sub("", m.group(0))
        titles.append(inner.strip())
        return "\u0001"
    cleaned = SPAN_RE.sub(_cap, text)
    cleaned = TAG_RE.sub("", cleaned)
    return html.unescape(cleaned), titles


def split_into_passages(raw_text, min_chars=40, max_chars=600):
    cleaned, titles = strip_tags_keep_titles(raw_text)
    lines = [l.strip() for l in cleaned.split("\n")]
    lines = [l for l in lines if l and l != "\u0001"]
    passages = [("title", t) for t in titles if t]
    buf = ""
    for line in lines:
        if len(line) > max_chars:
            if buf:
                passages.append(("para", buf)); buf = ""
            chunk = ""
            for s in SENT_SPLIT_RE.split(line):
                if len(chunk) + len(s) < max_chars:
                    chunk = (chunk + " " + s).strip()
                else:
                    if chunk:
                        passages.append(("sent", chunk))
                    chunk = s
            if chunk:
                passages.append(("sent", chunk))
        else:
            if len(buf) + len(line) < max_chars:
                buf = (buf + " " + line).strip()
            else:
                if buf:
                    passages.append(("para", buf))
                buf = line
    if buf:
        passages.append(("para", buf))
    merged, carry, carry_type = [], "", "para"
    for typ, txt in passages:
        if carry:
            txt = (carry + " " + txt).strip(); carry = ""
        if len(txt) < min_chars and typ != "title":
            carry, carry_type = txt, typ
            continue
        merged.append((typ, txt))
    if carry:
        merged.append((carry_type, carry))
    return merged


def add_book(book):
    db = sqlite3.connect(DB)
    cur = db.cursor()

    cur.execute(
        "INSERT OR REPLACE INTO books VALUES (?,?,?,?,?,?,?,?,?)",
        (
            book["book_id"], book["book_name"], book.get("author_id"), book.get("author_name"),
            book.get("cat_id"), book.get("cat_name"), len(book["pages"]), len(book["pages"]),
            book.get("info", ""),
        ),
    )

    cur.execute("SELECT MAX(passage_id) FROM passages")
    next_pid = (cur.fetchone()[0] or 0) + 1
    new_passage_rows = []
    new_fts_page_rows = []

    for page in book["pages"]:
        text_orig = page["text_orig"]
        new_fts_page_rows.append(
            (text_orig, text_orig, book["book_id"], book["book_name"],
             page.get("pg"), page.get("vol"), page.get("printed_page"))
        )
        for idx, (typ, txt) in enumerate(split_into_passages(text_orig)):
            new_passage_rows.append(
                (next_pid, book["book_id"], book["book_name"], page.get("pg"),
                 page.get("vol"), page.get("printed_page"), idx, typ, txt)
            )
            next_pid += 1

    cur.executemany(
        "INSERT INTO pages_fts(text_norm, text_orig, book_id, book_name, pg, vol, printed_page) VALUES (?,?,?,?,?,?,?)",
        new_fts_page_rows,
    )
    cur.executemany("INSERT INTO passages VALUES (?,?,?,?,?,?,?,?,?)", new_passage_rows)
    cur.executemany(
        "INSERT INTO passages_fts(text, book_name, passage_id) VALUES (?,?,?)",
        [(r[8], r[2], r[0]) for r in new_passage_rows],
    )
    db.commit()
    print(f"أُضيفت {len(new_passage_rows)} فقرة/جملة من كتاب '{book['book_name']}' دون إعادة بناء الفهارس القديمة.", file=sys.stderr)

    # ---- تحديث FastText تدريجيًا (build_vocab update=True + train على النص الجديد فقط) ----
    new_tokenized = [tokenize(r[8]) for r in new_passage_rows]
    ft = FastText.load("fasttext_balagha.model")
    ft.build_vocab(new_tokenized, update=True)
    ft.train(new_tokenized, total_examples=len(new_tokenized), epochs=ft.epochs)
    ft.save("fasttext_balagha.model")
    print("تم تحديث نموذج FastText تدريجيًا (بدون إعادة تدريب كامل).", file=sys.stderr)

    # ---- إلحاق متجهات LSA للفقرات الجديدة (تحويل فقط، بدون إعادة تدريب SVD) ----
    with open("tfidf_vectorizer.pkl", "rb") as f:
        vectorizer = pickle.load(f)
    with open("svd_model.pkl", "rb") as f:
        svd = pickle.load(f)
    joined = [" ".join(tk) for tk in new_tokenized]
    new_tfidf = vectorizer.transform(joined)
    new_lsa = svd.transform(new_tfidf)
    norms = np.linalg.norm(new_lsa, axis=1, keepdims=True)
    norms[norms == 0] = 1
    new_lsa = (new_lsa / norms).astype(np.float32)

    old_vectors = np.load("passage_vectors_lsa.npy")
    with open("passage_ids.pkl", "rb") as f:
        old_ids = pickle.load(f)
    all_vectors = np.vstack([old_vectors, new_lsa])
    all_ids = old_ids + [r[0] for r in new_passage_rows]
    np.save("passage_vectors_lsa.npy", all_vectors)
    with open("passage_ids.pkl", "wb") as f:
        pickle.dump(all_ids, f)
    print(f"تم إلحاق {len(new_lsa)} متجه LSA جديد (إجمالي الآن: {len(all_ids)}).", file=sys.stderr)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", required=True)
    args = ap.parse_args()
    with open(args.json, encoding="utf-8") as f:
        book = json.load(f)
    add_book(book)
