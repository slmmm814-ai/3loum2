# -*- coding: utf-8 -*-
"""
Phase 4: محرك بحث هجين على مستوى الفقرة.
يدمج:
  1) BM25/FTS5 (trigram) على passages_fts  -> مطابقة نصية دقيقة/جزئية
  2) fuzzy عبر vocab_fuzzy_variants          -> يلتقط الأخطاء المطبعية القريبة
  3) semantic عبر LSA (TF-IDF+SVD)           -> يلتقط التقارب الدلالي/المفاهيمي
  4) FastText                                 -> توسيع الاستعلام بمرادفات/صيغ قريبة
ثم reranking بوزن مُرجَّح (heuristic، لأنه لا يوجد وصول لنموذج reranker عصبي).
"""
import sqlite3, re, pickle, sys
import numpy as np
from gensim.models import FastText

DB = "فهرس_البلاغة_full_sqlite3_enhanced_v2_db"
AR_TOKEN_RE = re.compile(r"[\u0621-\u064A]+")
DIACRITICS_RE = re.compile(r"[\u064B-\u0652\u0670\u0640]")

_ft_model = None
_lsa_vectors = None
_passage_ids = None
_id_to_row = None
_vectorizer = None
_svd = None


def normalize_ar(text):
    text = DIACRITICS_RE.sub("", text)
    text = text.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    text = text.replace("ى", "ي").replace("ة", "ه")
    return text


def tokenize(text):
    return [normalize_ar(t) for t in AR_TOKEN_RE.findall(text) if len(t) > 1]


def _lazy_load():
    global _ft_model, _lsa_vectors, _passage_ids, _id_to_row, _vectorizer, _svd
    if _ft_model is None:
        _ft_model = FastText.load("fasttext_balagha.model")
    if _lsa_vectors is None:
        _lsa_vectors = np.load("passage_vectors_lsa.npy")
        with open("passage_ids.pkl", "rb") as f:
            _passage_ids = pickle.load(f)
        _id_to_row = {pid: i for i, pid in enumerate(_passage_ids)}
        with open("tfidf_vectorizer.pkl", "rb") as f:
            _vectorizer = pickle.load(f)
        with open("svd_model.pkl", "rb") as f:
            _svd = pickle.load(f)


def expand_query_fasttext(query_tokens, topn=3):
    """يضيف كلمات قريبة دلاليًا/صرفيًا من FastText لتوسيع الاستعلام."""
    _lazy_load()
    expansions = set(query_tokens)
    for tok in query_tokens:
        try:
            for w, score in _ft_model.wv.most_similar(tok, topn=topn):
                if score > 0.55:
                    expansions.add(w)
        except KeyError:
            continue
    return list(expansions)


def fuzzy_variants(db, query_tokens):
    """يبحث عن أخطاء طباعية محتملة قريبة من كلمات الاستعلام عبر vocab_fuzzy_variants."""
    cur = db.cursor()
    variants = set()
    for tok in query_tokens:
        cur.execute(
            """SELECT word1, word2 FROM vocab_fuzzy_variants
               WHERE word1 = ? OR word2 = ? LIMIT 5""",
            (tok, tok),
        )
        for w1, w2 in cur.fetchall():
            variants.add(w1)
            variants.add(w2)
    return variants


def bm25_search(db, query_text, limit=50):
    """بحث FTS5 (trigram) مع ترتيب BM25 المدمج في SQLite."""
    cur = db.cursor()
    q = query_text.strip()
    if not q:
        return []
    try:
        cur.execute(
            """SELECT passage_id, bm25(passages_fts) AS score
               FROM passages_fts WHERE text MATCH ?
               ORDER BY score LIMIT ?""",
            (q, limit),
        )
        rows = cur.fetchall()
    except sqlite3.OperationalError:
        return []
    if not rows:
        return []
    scores = np.array([r[1] for r in rows])
    # bm25() في SQLite أصغر=أفضل؛ نعكسها ونطبّعها إلى [0,1]
    inv = -scores
    inv = (inv - inv.min()) / (inv.max() - inv.min() + 1e-9)
    return [(pid, float(s)) for pid, s in zip([r[0] for r in rows], inv)]


def semantic_search(query_text, limit=50):
    """بحث دلالي عبر مقارنة متجه LSA للاستعلام بمتجهات الفقرات (جيب التمام)."""
    _lazy_load()
    tokens = tokenize(query_text)
    if not tokens:
        return []
    joined = " ".join(tokens)
    q_tfidf = _vectorizer.transform([joined])
    q_lsa = _svd.transform(q_tfidf)
    norm = np.linalg.norm(q_lsa)
    if norm == 0:
        return []
    q_lsa = (q_lsa / norm).astype(np.float32)
    sims = (_lsa_vectors @ q_lsa[0])
    top_idx = np.argsort(-sims)[:limit]
    return [(_passage_ids[i], float(sims[i])) for i in top_idx if sims[i] > 0]


def hybrid_search(query_text, top_k=15, weights=None):
    """
    البحث الهجين النهائي: يدمج BM25 + semantic (+ fuzzy/fasttext كتوسيع للاستعلام)
    عبر reranking بوزن مُرجَّح، ثم يعيد أفضل top_k فقرة مع بيانات الكتاب/الصفحة.
    """
    weights = weights or {"bm25": 0.5, "semantic": 0.4, "exact_phrase_bonus": 0.1}
    db = sqlite3.connect(DB)

    query_tokens = tokenize(query_text)
    fuzzy = fuzzy_variants(db, query_tokens)
    if fuzzy:
        expanded_query = query_text + " " + " ".join(fuzzy)
    else:
        expanded_query = query_text

    bm25_results = dict(bm25_search(db, expanded_query, limit=80))
    sem_results = dict(semantic_search(query_text, limit=80))

    all_ids = set(bm25_results) | set(sem_results)
    combined = []
    for pid in all_ids:
        b = bm25_results.get(pid, 0.0)
        s = sem_results.get(pid, 0.0)
        score = weights["bm25"] * b + weights["semantic"] * s
        combined.append((pid, score, b, s))

    combined.sort(key=lambda x: -x[1])
    combined = combined[: top_k * 3]  # مرشحون لإعادة الترتيب

    # reranking heuristic: تعزيز إن ظهرت عبارة الاستعلام الحرفية كاملة في النص
    cur = db.cursor()
    reranked = []
    for pid, score, b, s in combined:
        cur.execute(
            "SELECT text, book_name, pg, vol, printed_page, passage_type FROM passages WHERE passage_id=?",
            (pid,),
        )
        row = cur.fetchone()
        if not row:
            continue
        text, book_name, pg, vol, printed_page, ptype = row
        bonus = weights["exact_phrase_bonus"] if query_text.strip() and query_text.strip() in text else 0.0
        final_score = score + bonus
        reranked.append(
            {
                "passage_id": pid,
                "score": round(final_score, 4),
                "bm25_component": round(b, 4),
                "semantic_component": round(s, 4),
                "book_name": book_name,
                "pg": pg,
                "vol": vol,
                "printed_page": printed_page,
                "type": ptype,
                "text": text,
            }
        )

    reranked.sort(key=lambda x: -x["score"])
    return reranked[:top_k]


if __name__ == "__main__":
    q = sys.argv[1] if len(sys.argv) > 1 else "الاستعارة والتشبيه"
    for r in hybrid_search(q, top_k=8):
        print(f"[{r['score']}] {r['book_name']} صفحة {r['pg']} :: {r['text'][:100]}")
