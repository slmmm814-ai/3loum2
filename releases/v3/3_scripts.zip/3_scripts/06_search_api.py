# -*- coding: utf-8 -*-
"""
Phase 6: واجهة API للبحث.
تشغيل: python3 06_search_api.py
ثم: GET http://localhost:8008/search?q=الاستعارة&top_k=10
"""
from flask import Flask, request, jsonify
import sqlite3
import importlib.util, os

_here = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("hybrid_search_module", os.path.join(_here, "04_hybrid_search.py"))
hybrid = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(hybrid)

app = Flask(__name__)
DB = "فهرس_البلاغة_full_sqlite3_enhanced_v2_db"


@app.route("/search", methods=["GET"])
def search():
    q = request.args.get("q", "").strip()
    top_k = int(request.args.get("top_k", 10))
    book_id = request.args.get("book_id", type=int)
    if not q:
        return jsonify({"error": "أضف معامل q في الرابط، مثل ?q=الاستعارة"}), 400
    results = hybrid.hybrid_search(q, top_k=top_k)
    if book_id:
        results = [r for r in results if True]  # ملاحظة: للتصفية بحسب كتاب أضف book_id لجدول passages في الاستعلام
    return jsonify({"query": q, "count": len(results), "results": results})


@app.route("/book/<int:book_id>", methods=["GET"])
def get_book(book_id):
    db = sqlite3.connect(DB)
    cur = db.cursor()
    cur.execute("SELECT * FROM books WHERE book_id=?", (book_id,))
    row = cur.fetchone()
    if not row:
        return jsonify({"error": "كتاب غير موجود"}), 404
    cols = [d[0] for d in cur.description]
    return jsonify(dict(zip(cols, row)))


@app.route("/passage/<int:passage_id>", methods=["GET"])
def get_passage(passage_id):
    db = sqlite3.connect(DB)
    cur = db.cursor()
    cur.execute("SELECT * FROM passages WHERE passage_id=?", (passage_id,))
    row = cur.fetchone()
    if not row:
        return jsonify({"error": "فقرة غير موجودة"}), 404
    cols = [d[0] for d in cur.description]
    return jsonify(dict(zip(cols, row)))


@app.route("/citations/<int:book_id>", methods=["GET"])
def get_citations(book_id):
    db = sqlite3.connect(DB)
    cur = db.cursor()
    cur.execute(
        "SELECT * FROM citations_unified WHERE source_book_id=? OR target_book_id=?",
        (book_id, book_id),
    )
    cols = [d[0] for d in cur.description]
    rows = [dict(zip(cols, r)) for r in cur.fetchall()]
    return jsonify({"book_id": book_id, "count": len(rows), "citations": rows})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8008)
