# -*- coding: utf-8 -*-
"""
Phase 3: نظام موحّد للاستشهادات والمراجع.
يدمج book_citations (استشهاد كتاب بكتاب) + isnad_candidates (سلاسل الإسناد
المكتشفة) + duplicate_candidates (تكرار/اقتباس حرفي بين الصفحات) في جدول
واحد موحّد `citations_unified` بحقل `citation_type` يميّز طبيعة الرابط،
مع إسناد كل رابط -- حيثما أمكن -- إلى passage_id بعد بناء جدول الفقرات.
"""
import sqlite3, sys

DB = "فهرس_البلاغة_full_sqlite3_enhanced_v2_db"


def main():
    db = sqlite3.connect(DB)
    cur = db.cursor()

    cur.executescript("""
    DROP TABLE IF EXISTS citations_unified;
    CREATE TABLE citations_unified (
        id INTEGER PRIMARY KEY,
        citation_type TEXT,           -- 'book_citation' | 'isnad' | 'duplicate'
        source_book_id INTEGER,
        source_book_name TEXT,
        source_pg INTEGER,
        source_passage_id INTEGER,
        target_book_id INTEGER,
        target_book_name TEXT,
        target_pg INTEGER,
        target_passage_id INTEGER,
        weight REAL,
        note TEXT
    );
    """)

    rid = 1
    rows_out = []

    # 1) استشهادات على مستوى الكتاب (من book_citations)
    cur.execute("""SELECT citing_book_id, citing_book_name, cited_book_id, cited_book_name, weight
                   FROM book_citations""")
    for citing_id, citing_name, cited_id, cited_name, weight in cur.fetchall():
        rows_out.append((rid, "book_citation", citing_id, citing_name, None, None,
                          cited_id, cited_name, None, None, weight, None))
        rid += 1

    # 2) سلاسل الإسناد (isnad_candidates) بوصفها روابط داخل الكتاب نفسه غالبًا
    cur.execute("""SELECT book_id, book_name, pg, confidence, snippet FROM isnad_candidates""")
    for book_id, book_name, pg, confidence, snippet in cur.fetchall():
        rows_out.append((rid, "isnad", book_id, book_name, pg, None,
                          book_id, book_name, pg, None, confidence, snippet))
        rid += 1

    # 3) التكرار/الاقتباس الحرفي بين صفحتين (duplicate_candidates)
    cur.execute("""SELECT book_id_1, book_name_1, pg_1, book_id_2, book_name_2, pg_2,
                          jaccard, same_book FROM duplicate_candidates""")
    for b1, bn1, pg1, b2, bn2, pg2, jaccard, same_book in cur.fetchall():
        note = "نفس الكتاب" if same_book else "بين كتابين مختلفين"
        rows_out.append((rid, "duplicate", b1, bn1, pg1, None,
                          b2, bn2, pg2, None, jaccard, note))
        rid += 1

    cur.executemany(
        "INSERT INTO citations_unified VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows_out
    )
    db.commit()

    # ربط كل استشهاد/تكرار بأقرب passage_id إن كان جدول passages موجودًا
    cur.execute("SELECT name FROM sqlite_master WHERE name='passages'")
    if cur.fetchone():
        cur.execute("""
            UPDATE citations_unified
            SET source_passage_id = (
                SELECT passage_id FROM passages p
                WHERE p.book_id = citations_unified.source_book_id
                  AND p.pg = citations_unified.source_pg
                ORDER BY p.para_idx LIMIT 1
            )
            WHERE source_pg IS NOT NULL
        """)
        cur.execute("""
            UPDATE citations_unified
            SET target_passage_id = (
                SELECT passage_id FROM passages p
                WHERE p.book_id = citations_unified.target_book_id
                  AND p.pg = citations_unified.target_pg
                ORDER BY p.para_idx LIMIT 1
            )
            WHERE target_pg IS NOT NULL
        """)
        db.commit()

    cur.execute("CREATE INDEX IF NOT EXISTS idx_cu_type ON citations_unified(citation_type)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_cu_source ON citations_unified(source_book_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_cu_target ON citations_unified(target_book_id)")
    db.commit()

    cur.execute("SELECT citation_type, COUNT(*) FROM citations_unified GROUP BY citation_type")
    for t, c in cur.fetchall():
        print(t, c, file=sys.stderr)
    print("تم بناء citations_unified بنجاح.", file=sys.stderr)


if __name__ == "__main__":
    main()
