# -*- coding: utf-8 -*-
"""
Phase 2: تدريب FastText محليًا على المتن نفسه (بديل أقوى من Word2Vec لأنه
subword-aware: يتعامل مع كلمات غير مرصودة والتصريف العربي الغني)
+ بناء متجهات دلالية لكل فقرة (TF-IDF -> SVD/LSA) لبحث دلالي حقيقي دون
الاعتماد على أي نموذج يُنزَّل من الإنترنت.
"""
import sqlite3, re, sys, pickle
import numpy as np
from gensim.models import FastText
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD

DB = "فهرس_البلاغة_full_sqlite3_enhanced_v2_db"
AR_TOKEN_RE = re.compile(r"[\u0621-\u064A]+")

DIACRITICS_RE = re.compile(r"[\u064B-\u0652\u0670\u0640]")

def normalize_ar(text):
    text = DIACRITICS_RE.sub("", text)
    text = text.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    text = text.replace("ى", "ي").replace("ة", "ه")
    return text

def tokenize(text):
    return [normalize_ar(t) for t in AR_TOKEN_RE.findall(text) if len(t) > 1]


def main():
    db = sqlite3.connect(DB)
    cur = db.cursor()
    cur.execute("SELECT passage_id, text FROM passages ORDER BY passage_id")
    rows = cur.fetchall()
    ids = [r[0] for r in rows]
    texts = [r[1] for r in rows]
    print(f"عدد الفقرات: {len(texts)}", file=sys.stderr)

    tokenized = [tokenize(t) for t in texts]

    # ---------- FastText ----------
    print("تدريب FastText ...", file=sys.stderr)
    ft = FastText(
        sentences=tokenized,
        vector_size=100,
        window=6,
        min_count=2,
        workers=4,
        epochs=10,
        sg=1,        # skip-gram
        min_n=2, max_n=5,
        bucket=200000,   # تقليل حاويات الـ n-grams (من 2M الافتراضي) لتصغير حجم الملف كثيرًا
    )
    ft.save("fasttext_balagha.model")
    print("تم حفظ fasttext_balagha.model", file=sys.stderr)

    cur.executescript("""
    DROP TABLE IF EXISTS fasttext_similarity;
    CREATE TABLE fasttext_similarity (
        id INTEGER PRIMARY KEY,
        word TEXT,
        related_word TEXT,
        similarity REAL
    );
    CREATE INDEX idx_ft_word ON fasttext_similarity(word);
    """)

    vocab_words = list(ft.wv.key_to_index.keys())
    insert_buf = []
    rid = 1
    for w in vocab_words:
        try:
            sims = ft.wv.most_similar(w, topn=10)
        except Exception:
            continue
        for related, score in sims:
            insert_buf.append((rid, w, related, float(score)))
            rid += 1
        if len(insert_buf) >= 20000:
            cur.executemany("INSERT INTO fasttext_similarity VALUES (?,?,?,?)", insert_buf)
            insert_buf = []
    if insert_buf:
        cur.executemany("INSERT INTO fasttext_similarity VALUES (?,?,?,?)", insert_buf)
    db.commit()
    print(f"تم إدخال جداول تشابه FastText لعدد كلمات: {len(vocab_words)}", file=sys.stderr)

    # ---------- TF-IDF + LSA (semantic vectors per passage) ----------
    print("بناء TF-IDF + LSA لمتجهات الفقرات ...", file=sys.stderr)
    joined = [" ".join(tk) if tk else "" for tk in tokenized]
    vectorizer = TfidfVectorizer(min_df=2, max_df=0.9, sublinear_tf=True)
    tfidf = vectorizer.fit_transform(joined)

    n_components = 200
    svd = TruncatedSVD(n_components=n_components, random_state=42)
    lsa_vectors = svd.fit_transform(tfidf)
    # تطبيع L2 لتسهيل تشابه جيب التمام بضرب المصفوفات
    norms = np.linalg.norm(lsa_vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1
    lsa_vectors = (lsa_vectors / norms).astype(np.float32)

    np.save("passage_vectors_lsa.npy", lsa_vectors)
    with open("passage_ids.pkl", "wb") as f:
        pickle.dump(ids, f)
    with open("tfidf_vectorizer.pkl", "wb") as f:
        pickle.dump(vectorizer, f)
    with open("svd_model.pkl", "wb") as f:
        pickle.dump(svd, f)

    print(f"تباين مُفسَّر بواسطة LSA (200 بُعد): {svd.explained_variance_ratio_.sum():.3f}", file=sys.stderr)
    print("تم حفظ passage_vectors_lsa.npy / passage_ids.pkl / tfidf_vectorizer.pkl / svd_model.pkl", file=sys.stderr)


if __name__ == "__main__":
    main()
